export class ArcadeAudio {
  private context: AudioContext | null = null;
  private oscillator: OscillatorNode | null = null;
  private gain: GainNode | null = null;
  private enabled = false;

  setEnabled(enabled: boolean) {
    this.enabled = enabled;
    if (!enabled && this.gain && this.context) this.gain.gain.setTargetAtTime(0, this.context.currentTime, 0.1);
  }

  async unlock() {
    if (!this.enabled) return;
    try {
      if (!this.context) {
        this.context = new AudioContext();
        this.oscillator = this.context.createOscillator();
        this.oscillator.type = 'sawtooth';
        const filter = this.context.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.value = 380;
        this.gain = this.context.createGain();
        this.gain.gain.value = 0;
        this.oscillator.connect(filter).connect(this.gain).connect(this.context.destination);
        this.oscillator.start();
      }
      await this.context.resume();
    } catch { /* Audio is optional when browser autoplay restrictions apply. */ }
  }

  update(speedRatio: number, running: boolean, boost: boolean) {
    if (!this.context || !this.gain || !this.oscillator) return;
    const now = this.context.currentTime;
    const rpm = (speedRatio * 5) % 1;
    this.oscillator.frequency.setTargetAtTime(38 + rpm * 55 + speedRatio * 32, now, 0.1);
    this.gain.gain.setTargetAtTime(this.enabled && running ? (boost ? 0.035 : 0.023) : 0, now, 0.12);
  }

  beep(frequency = 660, duration = 0.12) {
    if (!this.enabled || !this.context) return;
    const oscillator = this.context.createOscillator();
    const gain = this.context.createGain();
    oscillator.type = 'square';
    oscillator.frequency.value = frequency;
    gain.gain.setValueAtTime(0.045, this.context.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.context.currentTime + duration);
    oscillator.connect(gain).connect(this.context.destination);
    oscillator.start();
    oscillator.stop(this.context.currentTime + duration);
    oscillator.onended = () => { oscillator.disconnect(); gain.disconnect(); };
  }

  destroy() {
    this.oscillator?.stop();
    this.oscillator?.disconnect();
    void this.context?.close();
  }
}